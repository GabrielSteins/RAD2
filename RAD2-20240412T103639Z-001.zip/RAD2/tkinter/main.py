import tkinter as tk
from tkinter import ttk
import modelo
class PrincipalBD():
    def __init__(self,win):
        self.objBD = modelo.AppBD()
        self.janela = win
        
        self.treeProdutos = ttk.Treeview(self.janela,columns =("Código do produto","Nome","Preço"),show="headings")
        self.ExibirTela()

        self.treeProdutos.heading("Código do produto",text="Código do produto: ")
        self.treeProdutos.heading("Nome",text="Nome: ")
        self.treeProdutos.heading("Preço",text="Preço: ")
        self.treeProdutos.pack()

        self.lblNome = tk.Label(self.janela,text ="Nome: ")
        self.lblNome.pack()
        self.entryNome = tk.Entry(self.janela)
        self.entryNome.pack()
        
        self.lblPreco = tk.Label(self.janela,text ="Preço: ")
        self.lblPreco.pack()
        self.entryPreco = tk.Entry(self.janela)
        self.entryPreco.pack()
        self.btnCadastrar = tk.Button(self.janela,text="Adicionar",command=self.CadastrarProduto)
        self.btnCadastrar.pack()
    def CadastrarProduto(self):
        try:
            name = self.entryNome.get()
            price = float(self.entryPreco.get())
            self.objBD.inserirDados(name,price)
            self.ExibirTela()
            self.entryNome.delete(0,tk.END)
            self.Preco.delete(0,tk.END)
            print("Produto Cadastrado com Sucesso")
        except:
            print("Não foi possível fazer o cadastro")
    def ExibirTela(self):
        try:
            print("**Dados Disponíveis**")
            products = self.objBD.select_all_products()
            for product in products:
                self.treeProdutos.insert("",tk.END,values=product)
        except:
            print("Dados não encontrado")


            

janela = tk.Tk() #janela principal
product_app = PrincipalBD(janela)
janela.title("Janela")#titulo da jeanela
janela.geometry("900x700")#Tamanho da janela principal
janela.mainloop() 